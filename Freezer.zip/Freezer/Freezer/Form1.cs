using System.Data.SqlClient;

namespace Freezer
{
    public partial class Form1 : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();
        SqlDataReader dr;
        public Form1()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.myConnection());
         
         /*   cn.Open();
            MessageBox.Show("Database is connected");*/
        }

     

        private void button1_Click(object sender, EventArgs e)
        {
            /*      Form1 f1=new Form1();
                    f1.ShowDialog();
        */
            dgvTemperature.Rows.Clear();
            dgvTemperature.Refresh();

            int i = 0;
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tbTemperature ORDER BY temperature", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dgvTemperature.Rows.Add(i, dr["id"].ToString(), dr["temperature"].ToString());
            }
            dr.Close();
            cn.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to add this temperature?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tbTemperature(temperature)VALUES(@temperature)", cn);
                    cm.Parameters.AddWithValue("@temperature", textBox1.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Temperature has been successfully added", "Temp");
                    textBox1.Text = "";
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}