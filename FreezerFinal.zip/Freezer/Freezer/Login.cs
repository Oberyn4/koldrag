﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Freezer
{
    public partial class Login : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();
        SqlDataReader dr;
        string _pass = "";
  
        public Login()
        {
            InitializeComponent();
            cn=new SqlConnection(dbcon.myConnection());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string _username = "";
            try
            {
                bool found;
                cn.Open();
                cm=new SqlCommand("SELECT * FROM tbUser WHERE username= @username and password = @password", cn);
                cm.Parameters.AddWithValue("@username", textBox1.Text);
                cm.Parameters.AddWithValue("@password", textBox2.Text);
                dr = cm.ExecuteReader();
                dr.Read();
                if(dr.HasRows)
                {
                    found = true;
                    _username = dr["username"].ToString();
                    _pass = dr["password"].ToString();
                 
                }
                else
                {
                    found=false;
                }
                dr.Close();
                cn.Close();
                if(found)
                {
                  
                        MessageBox.Show("Welcome " + _username + "|", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox1.Clear();
                        textBox2.Clear();
                        this.Hide();
                        Form1 main = new Form1();
                        main.ShowDialog();

                    
                }
            }
            catch(Exception ex)
            {
               
            }
        }

  

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Exit Application?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
